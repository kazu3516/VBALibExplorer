﻿【ソフト名】	VBALibExplorer
【著作権者】　　kazu
【制作日】　　　2018/xx/xx
【種　別】	　　フリーソフトウェア
【連絡先】　　　kazu_3516@yahoo.co.jp
【配布元】　　　
【転載の可否】　可
【登 録 名】　　VBALibExplorer.exe
【圧縮形式】　　VBALibExplorer.zip
【動作環境】　　Windows7/8/10
【開発環境】　　.NetFramework4.5 / Visual Studio 2017

―――――――――――――――――――――――――――――――――――――
≪著作権および免責事項≫

　本ソフトはフリーソフトです。個人／団体／社内利用を問わず、ご自由にお使い下さい。
　なお，著作権は作者である"kazu"が保有しています。

　このソフトウェアを使用したことによって生じたすべての障害・損害・不具
合等に関しては、私と私の関係者および私の所属するいかなる団体・組織とも、
一切の責任を負いません。各自の責任においてご使用ください。


・はじめに
  VBALibExplorerは、Visual Basic for Application (VBA)のモジュールを管理するためのフリーソフトです。
  Windows7/8/10 で動作します。

  主な特長：
  1)
  2)
  3)
  4)

・ファイル構成
  /config
  /help
  /log
  /script
  /temp
  Kucl.dll
  log4net.dll
　VBALibExplorer.exe　　　　　　　　　　　　　　(本体)
  VBALibExplorer.exe.config
  WeifenLuo.WinFormsUI.Docking.dll
  WeifenLuo.WinFormsUI.Docking.ThemeVS2013.dll
  WeifenLuo.WinFormsUI.Docking.ThemeVS2015.dll
　readme.txt　　　　　　　　　　　　　　　　　　(この説明ファイル)

・インストール方法
  圧縮ファイルを解凍してください。


・アンインストール方法
 　削除したくなった時は、インストール時に作成したフォルダをすべて削除してください。
 　レジストリやその他のフォルダは使用していません。

・使用方法
　  解凍されたフォルダ内のVBALibExplorer.exeをダブルクリックして起動してください。


・制限事項


・補足


・その他


・以前のバージョンからの変更点
　ver0.00　　2018/xx/xx
　　公開

・最後に
　
　作成に関係してくださった方々に深く感謝致します。
　また、本作品を使用してくださっている、皆様にも深く感謝致します。



--以上--

